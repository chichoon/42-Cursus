=========
CAT ROBBER
=========

give me cute cat photo.

QUICK START
----------
1. add 'ex00' in your INSTALLED_APPS
2. include the ex00 url in project urls.py
3. python manage.py migrate
4. just upload cat. that's it.
